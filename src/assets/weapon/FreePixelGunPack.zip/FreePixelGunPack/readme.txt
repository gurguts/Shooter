---------------------------------------------------------------
                   PIXEL GUN PACK
---------------------------------------------------------------

Thanks for downloading!

Pixel Gun Pack contains 50 unique pixel art guns. Perfect for game developers, designers and pixel art fans.

What’s included?
Pistols (13 models)
Submachine Guns (SMGs) (14 models)
Shotguns (8 models)
Assault Rifles (7 models)
Sniper Rifles (4 models)
Light Machine Guns(2 models)
Explosive Weapons(2 models)

---------------------------------------------------------------

Usage License

You Can:
- Use this asset pack in commercial and non-commercial projects.  
- Incorporate the graphics in games, animations, applications, educational materials, etc.

You Can not:
- Sell, distribute, or share this pack in its original or modified form as a standalone product. 
- Upload the graphics to public repositories, asset packs, or similar collections. 
- Create competing products based on these graphics.

You Are Not Required To:
- You are not required to credit the source or author in your projects, but doing so is always appreciated. 

---------------------------------------------------------------

More of my asset packs and my games: https://domin-dev.itch.io 

---------------------------------------------------------------
